import React from 'react';
import Usersparticipations from './component/Usersparticipations';
import PollDisplay from './component/PollDisplay';
import Anotheruserparticipation from './component/Anotheruserparticipation';
import Thankyoumsg from './component/Thankyoumsg';
const App = () => {
  return (
    <div className='App'>
     
      <PollDisplay/>
      <Usersparticipations/>
     
    </div>
  );
}

export default App






























